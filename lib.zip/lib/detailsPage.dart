import 'package:flutter/material.dart';
import 'package:flutter_project_melanie/Venue.dart';


class DetailScreen extends StatelessWidget {
  // Declare a field that holds the Todo.
  final Venue venue;

  // In the constructor, require a Todo.
  DetailScreen({Key key, @required this.venue}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Use the Todo to create the UI.
    return Scaffold(
      appBar: AppBar(
        title: Text(venue.name),
        leading: CircleAvatar(
          backgroundImage: NetworkImage(
              venue.categories[0].icon.prefix + "32" +
                  venue.categories[0].icon.suffix),
        ),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            Text(venue.name),
            Text(venue.location.getFormattedAddress()),
            Row(
                children: <Widget>[
                  CircleAvatar(
                    backgroundImage: NetworkImage(
                        venue.categories[0].icon.prefix + "44" +
                            venue.categories[0].icon.suffix),
                  ),
                  Text(venue.categories[0].shortName)
                ],
            ),
          ],
        ),
      ),
    );
  }
}